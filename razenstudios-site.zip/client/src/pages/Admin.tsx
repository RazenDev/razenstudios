import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { ArrowRight, CheckCircle2, Edit3, FileArchive, ImagePlus, LogIn, Plus, Save, ShieldCheck, Trash2, UploadCloud, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

const categories = [
  ["setups", "Setups"], ["skripts", "Skripts"], ["plugins", "Plugins"], ["open-source", "Open Source"], ["discord-development", "Discord Development"], ["maps", "Maps"], ["configs", "Configs"],
] as const;

type FormState = { title: string; slug: string; description: string; category: typeof categories[number][0]; tags: string; link: string; status: "draft" | "published"; isFeatured: boolean; imageData?: string; fileData?: string; fileName?: string };
const emptyForm: FormState = { title: "", slug: "", description: "", category: "setups", tags: "", link: "", status: "published", isFeatured: false };

function readFile(file: File) {
  return new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file); });
}

export default function Admin() {
  const auth = trpc.auth.me.useQuery();
  const [form, setForm] = useState<FormState>(emptyForm);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [notice, setNotice] = useState("");
  const [saving, setSaving] = useState(false);
  const utils = trpc.useUtils();
  const resources = trpc.resources.adminList.useQuery(undefined, { enabled: auth.data?.role === "admin" });
  const create = trpc.resources.create.useMutation();
  const update = trpc.resources.update.useMutation();
  const remove = trpc.resources.remove.useMutation();

  if (auth.isLoading) return <div className="admin-loading" dir="rtl"><div className="pulse-dot" />جارٍ التحقق من صلاحية الإدارة...</div>;
  if (!auth.data) return <div className="auth-shell" dir="rtl"><div className="auth-card"><div className="brand-symbol">&lt;/&gt;</div><ShieldCheck size={30} /><h1>لوحة Razen</h1><p>سجّل الدخول بحساب Manus المصرّح له لإدارة الموارد ورفع الملفات.</p><Button onClick={() => startLogin()}><LogIn size={17} /> تسجيل الدخول</Button><Link href="/" className="muted-link">العودة للموقع</Link></div></div>;
  if (auth.data.role !== "admin") return <div className="auth-shell" dir="rtl"><div className="auth-card"><ShieldCheck size={30} /><h1>الوصول مقيّد</h1><p>حسابك مسجّل، لكن لا يملك دور الإدارة حاليًا. اطلب من مالك المشروع تفعيل صلاحية admin.</p><Link href="/" className="button button-primary">العودة للموقع <ArrowRight size={17} /></Link></div></div>;

  const reset = () => { setForm(emptyForm); setEditingId(null); setNotice(""); };
  const updateField = (field: keyof FormState, value: string | boolean) => setForm(current => ({ ...current, [field]: value }));
  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault(); setSaving(true); setNotice("");
    try {
      if (editingId) await update.mutateAsync({ ...form, id: editingId }); else await create.mutateAsync(form);
      await Promise.all([utils.resources.adminList.invalidate(), utils.resources.list.invalidate()]);
      setNotice(editingId ? "تم تحديث المورد بنجاح." : "تم نشر المورد بنجاح."); reset();
    } catch (error) { setNotice(error instanceof Error ? error.message : "تعذر حفظ المورد."); }
    finally { setSaving(false); }
  };
  const editResource = (item: any) => { setEditingId(item.id); setForm({ title: item.title, slug: item.slug, description: item.description, category: item.category, tags: item.tags || "", link: item.link || "", status: item.status, isFeatured: item.isFeatured }); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const deleteResource = async (id: number) => { if (!window.confirm("هل تريد حذف هذا المورد؟")) return; await remove.mutateAsync({ id }); await utils.resources.adminList.invalidate(); await utils.resources.list.invalidate(); setNotice("تم حذف المورد."); };

  return <div className="admin-shell" dir="rtl"><header className="admin-header"><div className="container admin-header-inner"><Link href="/" className="brand"><span className="brand-symbol">&lt;/&gt;</span><span><strong>RAZEN</strong><small>STUDIOS / CONTROL</small></span></Link><div className="admin-header-actions"><span className="admin-user"><span className="pulse-dot" /> {auth.data.name || auth.data.email || "Admin"}</span><Link href="/" className="back-link"><ArrowRight size={16} /> الموقع</Link></div></div></header><main className="container admin-main"><div className="admin-intro"><div><span className="section-kicker">CONTROL ROOM / 01</span><h1>إدارة الموارد</h1><p>انشر ما تريد، كرر ما ينجح، واترك الباقي للأرشيف.</p></div><span className="admin-badge"><ShieldCheck size={15} /> ADMIN ACCESS</span></div><div className="admin-grid"><form className="admin-form-panel" onSubmit={handleSubmit}><div className="panel-heading"><div><span className="section-kicker">{editingId ? "EDIT RESOURCE" : "NEW RESOURCE"}</span><h2>{editingId ? "تعديل مورد" : "إضافة مورد"}</h2></div>{editingId && <button type="button" className="icon-button" onClick={reset}><X size={17} /></button>}</div><label>العنوان<input required value={form.title} onChange={event => updateField("title", event.target.value)} placeholder="مثال: Neon Dashboard Config" /></label><div className="form-row"><label>القسم<select value={form.category} onChange={event => updateField("category", event.target.value)}>{categories.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><label>الرابط (اختياري)<input type="url" value={form.link} onChange={event => updateField("link", event.target.value)} placeholder="https://..." /></label></div><label>الوصف<textarea required rows={5} value={form.description} onChange={event => updateField("description", event.target.value)} placeholder="اشرح للمستخدم ماذا سيحصل عليه..." /></label><label>الوسوم <small>افصل بينها بفواصل</small><input value={form.tags} onChange={event => updateField("tags", event.target.value)} placeholder="discord, ui, setup" /></label><div className="upload-grid"><label className="upload-box"><ImagePlus size={22} /><strong>صورة الغلاف</strong><span>{form.imageData ? "تم اختيار صورة" : "PNG / JPG حتى 25MB"}</span><input type="file" accept="image/png,image/jpeg,image/webp" onChange={async event => { const file = event.target.files?.[0]; if (file) updateField("imageData", await readFile(file)); }} /></label><label className="upload-box"><FileArchive size={22} /><strong>ملف المورد</strong><span>{form.fileName || "ZIP / JSON / أي ملف حتى 25MB"}</span><input type="file" onChange={async event => { const file = event.target.files?.[0]; if (file) { updateField("fileData", await readFile(file)); updateField("fileName", file.name); } }} /></label></div><div className="form-row"><label>الحالة<select value={form.status} onChange={event => updateField("status", event.target.value as "draft" | "published")}><option value="published">منشور</option><option value="draft">مسودة</option></select></label><label className="checkbox-label"><input type="checkbox" checked={form.isFeatured} onChange={event => updateField("isFeatured", event.target.checked)} /> إبراز المورد في الواجهة</label></div>{notice && <div className="notice"><CheckCircle2 size={16} /> {notice}</div>}<Button type="submit" disabled={saving} className="save-button">{saving ? <UploadCloud className="spin" size={17} /> : editingId ? <Save size={17} /> : <Plus size={17} />} {saving ? "جارٍ الحفظ..." : editingId ? "حفظ التعديل" : "نشر المورد"}</Button></form><section className="admin-list-panel"><div className="panel-heading"><div><span className="section-kicker">RESOURCE INDEX</span><h2>الموارد الحالية</h2></div><span className="count-badge">{resources.data?.length ?? 0}</span></div><div className="admin-resource-list">{resources.isLoading ? <div className="empty-state">جارٍ تحميل القائمة...</div> : resources.data?.map(item => <div className="admin-resource-row" key={item.id}><img src={item.coverUrl || "/razen-cover.png"} alt="" /><div className="admin-resource-info"><strong>{item.title}</strong><span>{item.category} · {item.status === "published" ? "منشور" : "مسودة"}</span></div><div className="row-actions"><button className="icon-button" onClick={() => editResource(item)} aria-label="تعديل"><Edit3 size={16} /></button><button className="icon-button danger" onClick={() => deleteResource(item.id)} aria-label="حذف"><Trash2 size={16} /></button></div></div>)}</div></section></div></main></div>;
}
