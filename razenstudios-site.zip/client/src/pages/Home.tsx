import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowUpLeft, ChevronDown, ExternalLink, FileCode2, Github, Menu, Search, Sparkles, Terminal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";

const categories = [
  { key: "setups", label: "Setups", arabic: "إعدادات", icon: "01" },
  { key: "skripts", label: "Skripts", arabic: "سكريبتات", icon: "02" },
  { key: "plugins", label: "Plugins", arabic: "إضافات", icon: "03" },
  { key: "open-source", label: "Open Source", arabic: "مفتوح المصدر", icon: "04" },
  { key: "discord-development", label: "Discord Development", arabic: "تطوير Discord", icon: "05" },
  { key: "maps", label: "Maps", arabic: "خرائط", icon: "06" },
  { key: "configs", label: "Configs", arabic: "إعدادات متقدمة", icon: "07" },
];

const categoryMap = Object.fromEntries(categories.map(item => [item.key, item]));

function formatDate(value: string | Date) {
  return new Intl.DateTimeFormat("ar-SA", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value));
}

function ResourceCard({ resource, featured = false }: { resource: any; featured?: boolean }) {
  const category = categoryMap[resource.category] ?? { label: resource.category, arabic: "مورد", icon: "00" };
  return (
    <Link href={`/resource/${resource.slug}`} className={`resource-card group ${featured ? "resource-card-featured" : ""}`}>
      <div className="resource-card-cover">
        <img src={resource.coverUrl || "/razen-cover.png"} alt="" />
        <div className="cover-overlay" />
        <span className="card-code">RZN / {String(resource.id).padStart(2, "0")}</span>
        <span className="card-type">{category.label}</span>
        <ArrowUpLeft className="card-arrow" size={19} />
      </div>
      <div className="resource-card-body">
        <div className="eyebrow-row"><span>{category.arabic}</span><span>{formatDate(resource.createdAt)}</span></div>
        <h3>{resource.title}</h3>
        <p>{resource.description}</p>
        <div className="tag-row">
          {(resource.tags || "dev,resource").split(",").slice(0, 3).map((tag: string) => <span key={tag}>#{tag.trim()}</span>)}
        </div>
      </div>
    </Link>
  );
}

export default function Home() {
  const [, navigate] = useLocation();
  const [activeCategory, setActiveCategory] = useState("");
  const [search, setSearch] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const resourcesQuery = trpc.resources.list.useQuery({ category: activeCategory || undefined, search: search || undefined });
  const resources = resourcesQuery.data ?? [];
  const featured = useMemo(() => resources.filter(item => item.isFeatured).slice(0, 2), [resources]);

  return (
    <div className="site-shell" dir="rtl">
      <header className="site-header">
        <div className="container header-inner">
          <Link href="/" className="brand" aria-label="Razen Studios home">
            <span className="brand-symbol">&lt;/&gt;</span>
            <span><strong>RAZEN</strong><small>STUDIOS / 2026</small></span>
          </Link>
          <nav className={`main-nav ${mobileMenu ? "is-open" : ""}`}>
            <a href="#resources" onClick={() => setMobileMenu(false)}>الموارد</a>
            <a href="#categories" onClick={() => setMobileMenu(false)}>الأقسام</a>
            <a href="#about" onClick={() => setMobileMenu(false)}>عن Razen</a>
            <Link href="/admin" onClick={() => setMobileMenu(false)}>لوحة الإدارة</Link>
          </nav>
          <div className="header-actions">
            <button className="icon-button mobile-menu-button" onClick={() => setMobileMenu(value => !value)} aria-label="فتح القائمة">{mobileMenu ? <X size={19} /> : <Menu size={19} />}</button>
            <Button className="header-cta" onClick={() => navigate("#resources")}>استكشف الموارد <ArrowLeft size={16} /></Button>
          </div>
        </div>
      </header>

      <main>
        <section className="hero-section">
          <div className="hero-grid" />
          <div className="hero-orb hero-orb-one" />
          <div className="hero-orb hero-orb-two" />
          <div className="container hero-content">
            <div className="hero-copy">
              <div className="status-line"><span className="pulse-dot" /> RZN / OPEN RESOURCE LAB</div>
              <h1>ابنِ <em>أسرع.</em><br />شارك <em>أذكى.</em></h1>
              <p>مكتبة Razen Studios المفتوحة — موارد، إعدادات وأدوات جاهزة للمطورين وصناع المجتمعات الرقمية.</p>
              <div className="hero-actions">
                <a className="button button-primary" href="#resources">تصفح الموارد <ArrowLeft size={17} /></a>
                <a className="button button-ghost" href="#about">اكتشف Razen <ArrowUpLeft size={17} /></a>
              </div>
              <div className="hero-meta"><span><strong>07</strong> أقسام</span><span><strong>∞</strong> أفكار</span><span><strong>01</strong> مجتمع</span></div>
            </div>
            <div className="hero-art" aria-label="هوية Razen Studios">
              <div className="hero-frame">
                <img src="/razen-cover.png" alt="هوية Razen Studios التقنية" />
                <div className="hero-frame-overlay" />
                <span className="frame-label frame-label-top">SYSTEM / ACTIVE</span>
                <span className="frame-label frame-label-bottom">CREATIVE DEV TOOLS</span>
                <span className="frame-corner corner-tl" /><span className="frame-corner corner-br" />
              </div>
              <div className="art-caption"><span>01</span><span>THE RAZEN SIGNAL</span><span>↗</span></div>
            </div>
          </div>
        </section>

        <section className="ticker" aria-label="Razen signal"><div className="ticker-track"><span>OPEN SOURCE / COMMUNITY / BUILT TO SHARE</span><b>✦</b><span>OPEN SOURCE / COMMUNITY / BUILT TO SHARE</span><b>✦</b><span>OPEN SOURCE / COMMUNITY / BUILT TO SHARE</span></div></section>

        <section className="section-block categories-section" id="categories">
          <div className="container">
            <div className="section-heading"><div><span className="section-kicker">01 / INDEX</span><h2>كل ما تحتاجه<br /><span>للبداية.</span></h2></div><p>رتّب رحلتك التقنية كما تريد. موارد عملية، منظمة، ومصممة لتختصر عليك الطريق.</p></div>
            <div className="category-list">
              {categories.map(category => <button key={category.key} className={`category-row ${activeCategory === category.key ? "active" : ""}`} onClick={() => { setActiveCategory(category.key); document.getElementById("resources")?.scrollIntoView({ behavior: "smooth" }); }}><span className="category-number">{category.icon}</span><span className="category-label"><strong>{category.label}</strong><small>{category.arabic}</small></span><ArrowUpLeft className="category-arrow" size={20} /></button>)}
            </div>
          </div>
        </section>

        <section className="section-block resources-section" id="resources">
          <div className="container">
            <div className="resource-toolbar"><div><span className="section-kicker">02 / LIBRARY</span><h2>{activeCategory ? categoryMap[activeCategory]?.label : "آخر الإصدارات"}</h2></div><div className="toolbar-controls"><label className="search-field"><Search size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="ابحث عن مورد..." /></label><button className="filter-button" onClick={() => setActiveCategory("")}>{activeCategory ? "إظهار الكل" : "كل الأقسام"}<ChevronDown size={16} /></button></div></div>
            {resourcesQuery.isLoading ? <div className="empty-state"><Sparkles className="spin" size={24} />جاري تحميل الموارد...</div> : resources.length === 0 ? <div className="empty-state"><FileCode2 size={28} /><strong>لا توجد نتائج بعد</strong><span>جرّب كلمة أخرى أو اختر قسمًا مختلفًا.</span></div> : <div className="resource-grid">{(featured.length ? featured : resources.slice(0, 2)).map(resource => <ResourceCard key={`featured-${resource.id}`} resource={resource} featured />)}{resources.filter(item => !featured.some(feature => feature.id === item.id)).map(resource => <ResourceCard key={resource.id} resource={resource} />)}</div>}
          </div>
        </section>

        <section className="manifesto-section" id="about"><div className="container manifesto-inner"><div className="manifesto-mark">✦</div><div><span className="section-kicker">03 / MANIFESTO</span><h2>المشاركة ليست<br /><em>ميزة إضافية.</em></h2></div><p>في Razen، كل مورد يبدأ كفكرة صغيرة وينتهي بأثر أكبر. نشارك ما نبني، ونترك الباب مفتوحًا لمن يريد أن يطوّر الخطوة التالية.</p><Link href="/admin" className="manifesto-link">أضف موردًا جديدًا <ArrowLeft size={17} /></Link></div></section>
      </main>

      <footer className="site-footer"><div className="container footer-inner"><Link href="/" className="brand"><span className="brand-symbol">&lt;/&gt;</span><span><strong>RAZEN</strong><small>STUDIOS / OPEN BY DEFAULT</small></span></Link><p>موارد جاهزة، من المطورين إلى المطورين.</p><div className="footer-links"><a href="#resources">المكتبة</a><a href="#about">عن المشروع</a><a href="https://discord.com" target="_blank" rel="noreferrer"><Github size={15} /> Discord</a></div><span className="footer-copy">© 2026 RAZEN STUDIOS</span></div></footer>
    </div>
  );
}
