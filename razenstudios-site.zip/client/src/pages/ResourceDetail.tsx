import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ArrowRight, CalendarDays, Check, Download, ExternalLink, FileCode2, Hash, Share2 } from "lucide-react";
import { Link, useParams } from "wouter";

const labels: Record<string, { label: string; arabic: string }> = {
  setups: { label: "Setups", arabic: "إعدادات" },
  skripts: { label: "Skripts", arabic: "سكريبتات" },
  plugins: { label: "Plugins", arabic: "إضافات" },
  "open-source": { label: "Open Source", arabic: "مفتوح المصدر" },
  "discord-development": { label: "Discord Development", arabic: "تطوير Discord" },
  maps: { label: "Maps", arabic: "خرائط" },
  configs: { label: "Configs", arabic: "إعدادات متقدمة" },
};

export default function ResourceDetail() {
  const { slug } = useParams<{ slug: string }>();
  const query = trpc.resources.bySlug.useQuery({ slug: slug || "" }, { enabled: Boolean(slug) });
  if (query.isLoading) return <div className="detail-loading" dir="rtl"><div className="loading-line" /><div className="loading-line short" /><div className="loading-box" /></div>;
  if (!query.data) return <div className="not-found-shell" dir="rtl"><FileCode2 size={34} /><h1>المورد غير موجود</h1><p>قد يكون الرابط قديمًا أو تم نقل المورد.</p><Link href="/" className="button button-primary">العودة للمكتبة <ArrowRight size={17} /></Link></div>;
  const resource = query.data;
  const category = labels[resource.category] ?? { label: resource.category, arabic: "مورد" };
  const actionUrl = resource.fileUrl || resource.link;

  return <div className="site-shell" dir="rtl"><header className="site-header"><div className="container header-inner"><Link href="/" className="brand"><span className="brand-symbol">&lt;/&gt;</span><span><strong>RAZEN</strong><small>STUDIOS / RESOURCE VIEW</small></span></Link><Link href="/" className="back-link"><ArrowRight size={17} /> العودة للمكتبة</Link></div></header><main className="detail-page"><div className="container"><div className="breadcrumbs"><Link href="/">المكتبة</Link><span>/</span><span>{category.label}</span><span>/</span><strong>{resource.title}</strong></div><div className="detail-layout"><div className="detail-visual"><img src={resource.coverUrl || "/razen-cover.png"} alt="" /><div className="detail-visual-overlay" /><span>RZN / {String(resource.id).padStart(2, "0")}</span><b>{category.label}</b></div><article className="detail-copy"><div className="status-line"><span className="pulse-dot" /> {category.arabic} / RESOURCE</div><h1>{resource.title}</h1><p className="detail-description">{resource.description}</p><div className="detail-meta"><span><CalendarDays size={16} /> {new Intl.DateTimeFormat("ar-SA", { day: "numeric", month: "long", year: "numeric" }).format(new Date(resource.createdAt))}</span><span><Hash size={16} /> {resource.tags || "Razen"}</span></div>{actionUrl ? <a className="button button-primary detail-action" href={actionUrl} target="_blank" rel="noreferrer">{resource.fileUrl ? <Download size={18} /> : <ExternalLink size={18} />} {resource.fileUrl ? `تحميل ${resource.fileName || "الملف"}` : "فتح الرابط"}</a> : <Button disabled className="detail-action"><Check size={18} /> متاح قريبًا</Button>}<button className="share-button" onClick={() => navigator.clipboard?.writeText(window.location.href)}><Share2 size={16} /> نسخ رابط المورد</button><div className="detail-tags">{(resource.tags || "razen,resource").split(",").map(tag => <span key={tag}>#{tag.trim()}</span>)}</div></article></div></div></main><footer className="site-footer"><div className="container footer-inner"><span className="footer-copy">© 2026 RAZEN STUDIOS</span><Link href="/admin">لوحة الإدارة</Link></div></footer></div>;
}
